const allowedOrigins = ["http://localhost:3000"]

module.exports = allowedOrigins
